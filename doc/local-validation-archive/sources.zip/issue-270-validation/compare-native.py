from pathlib import Path
import json,os,subprocess
root=Path(__file__).resolve().parent
out=root/'native-comparison';out.mkdir(exist_ok=True)
commands=[]
for original in json.loads((root.parent/'issue-268-validation/native-comparison/commands.json').read_text()):
    variant='base' if '/baseline/' in original[0] else 'candidate'
    binary=root.parent/'issue-268-validation/release/src/bin/IntaRNA' if variant=='base' else root/'release/src/bin/IntaRNA'
    command=[str(binary),*[x.replace('issue-268-validation/native-comparison','issue-270-validation/native-comparison') for x in original[1:]]]
    commands.append(command)
    name=next(Path(x.split(':',1)[1]).stem for x in command if x.startswith('--out=bpProb:'))
    result=subprocess.run(command,capture_output=True,check=True,env=dict(os.environ,OMP_NUM_THREADS='1'))
    (out/(name+'.stdout')).write_bytes(result.stdout)
    (out/(name+'.stderr')).write_bytes(result.stderr)
    print(name,flush=True)
(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
checks=[]
for base in sorted(out.glob('*-base.csv')):
    candidate=base.with_name(base.name.replace('-base','-candidate'))
    for suffix in ['.csv','.stdout','.stderr']:
        assert base.with_suffix(suffix).read_bytes()==candidate.with_suffix(suffix).read_bytes(),(base,suffix)
    checks.append(base.name)
assert len(checks)==12
(out/'results.json').write_text(json.dumps({'byte_identical_cases':checks},indent=2)+'\n')
print('All 12 native prediction/pair files identical')
