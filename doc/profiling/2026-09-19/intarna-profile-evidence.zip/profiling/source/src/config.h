/* src/config.h.  Generated from config.h.in by configure.  */
/* src/config.h.in.  Generated from configure.ac by autoheader.  */

/* define if the Boost library is available */
#define HAVE_BOOST /**/

/* define if the Boost::Filesystem library is available */
#define HAVE_BOOST_FILESYSTEM /**/

/* define if the Boost::IOStreams library is available */
#define HAVE_BOOST_IOSTREAMS /**/

/* define if the Boost::PROGRAM_OPTIONS library is available */
#define HAVE_BOOST_PROGRAM_OPTIONS /**/

/* define if the Boost::Regex library is available */
#define HAVE_BOOST_REGEX /**/

/* define if the Boost::System library is available */
#define HAVE_BOOST_SYSTEM /**/

/* define if the compiler supports basic C++23 syntax */
#define HAVE_CXX23 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Define to 1 if you have `z' library (-lz) */
#define HAVE_LIBZ 1

/* Define if OpenMP is enabled */
#define HAVE_OPENMP 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdio.h> header file. */
#define HAVE_STDIO_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Disabling console log coloring */
#define INTARNA_LOG_COLORING 1

/* Disabling multi-threading support */
#define INTARNA_MULITHREADING 1

/* Disabling multiprecision partition function */
#define INTARNA_MULTIPRECISION 0

/* Run in normal mode with minimal assertions */
#define NDEBUG 1

/* Name of package */
#define PACKAGE "intaRNA"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT ""

/* Define to the full name of this package. */
#define PACKAGE_NAME "IntaRNA"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "IntaRNA 3.4.1"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "intaRNA"

/* Define to the home page for this package. */
#define PACKAGE_URL "http://www.bioinf.uni-freiburg.de"

/* Define to the version of this package. */
#define PACKAGE_VERSION "3.4.1"

/* Define to 1 if all of the C90 standard headers exist (not just the ones
   required in a freestanding environment). This macro is provided for
   backward compatibility; new code need not use it. */
#define STDC_HEADERS 1

/* Version number of package */
#define VERSION "3.4.1"

/* Run in DEBUG mode with additional assertions and debug output */
/* #undef _DEBUG */

/* Define to `unsigned int' if <sys/types.h> does not define. */
/* #undef size_t */
